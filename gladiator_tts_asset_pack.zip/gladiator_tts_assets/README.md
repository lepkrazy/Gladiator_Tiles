# Gladiator Tabletop Simulator Asset Pack

Core first-pass production assets for the corrected 234-tile pool.

## Included
- 234 individual 512x256 RGBA domino faces
- No visible manufacturing-set designators
- One shared tile back
- Three 13x6 sprite sheets corresponding to the three manufacturing groups
- Four weapon icon crops derived from the generated visual style board
- Tile CSV and JSON manifests
- Lua naming scaffold
- Full visual design board and 12-tile sample sheet

## TTS import notes
- Import each domino as a Custom Tile for direct physical placement, or use the sheets as source atlases for scripted spawning.
- Upload assets to TTS Cloud for multiplayer use.
- Keep the CSV/JSON manufacturing_group field for internal generation and debugging only. It is intentionally absent from tile art.
- Images are RGB/RGBA and kept below 4096 pixels per dimension.
