-- Gladiator Tabletop Simulator asset scaffold
GLADIATOR = { tile_count = 234, tile_back = "tile_back.png" }
function onLoad()
  print("Gladiator asset scaffold loaded: 234 domino tiles")
end
